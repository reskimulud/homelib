<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h1>buat transaksi</h1>
    <br>

    <form action="" method="POST">
        <input type="number" name="jumlah" id="jumlah">
        <button type="submit" name="submitJmlh">Pilih</button>
    </form>

    <?php if (isset($_POST['jumlah'])) : ?>

    <?php $jumlah = $_POST['jumlah'] ?>

    <br><br>
    <form action="<?= base_url('test/action/') . $jumlah; ?>" method="POST">
        <?php for ($i = 1; $i <= $jumlah; $i++) : ?>
        <select name="produk<?= $i; ?>" id="">
            <option value="" selected disabled>--pilih produk--</option>
            <?php foreach ($product as $pro) : ?>
            <option value="<?= $pro['id']; ?>"><?= $pro['title']; ?></option>
            <?php endforeach ?>
        </select>
        <label for="qty">Kuantiti</label>
        <input type="number" name="qty<?= $i; ?>" id="qty">
        <?php endfor; ?>
        <select name="payment" id="payment">
            <?php foreach ($payment as $py) : ?>
            <option value="<?= $py['id']; ?>"><?= $py['method']; ?></option>
            <?php endforeach; ?>
        </select>
        <button type="submit">Submit</button>
    </form>
    <br>

    <?php endif; ?>
</body>

</html>