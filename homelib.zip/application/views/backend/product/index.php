<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0 text-dark"><?= $title; ?></h1>
                </div><!-- /.col -->
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="#">Home</a></li>
                        <li class="breadcrumb-item active">Dashboard v2</li>
                    </ol>
                </div><!-- /.col -->
            </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">

            <div class="row">
                <div class="col-lg-12">
                    <div class="flash-data" data-flashdata="<?= $this->session->flashdata('message') ?>"></div>
                    <?php if (validation_errors()) : ?>
                    <div class="flash-error" data-flasherror="<?= $this->session->flashdata('error') ?>"></div>
                    <?php endif; ?>
                    <div class="flash-error" data-flasherror="<?= $this->session->flashdata('error') ?>"></div>

                    <div class="tooltip-menu">
                        <button href="" class="btn btn-primary mb-4 " data-toggle="modal" data-target="#newProdukModal"
                            data-popup="tooltip" data-placement="top" title="Tambah Produk">
                            <i class=" fas fa-fw fa-plus-square"></i>
                            Tambah Produk
                        </button>
                    </div>

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary"><i class="fa fa-table"></i> Data Produk</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-hover table-responsive" id="dataTable" width="100%"
                                    cellspacing="0">
                                    <thead align="center">
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Thumbnail</th>
                                            <th scope="col">Nama Produk</th>
                                            <th scope="col">Deskripsi</th>
                                            <th scope="col">Tanggal</th>
                                            <th scope="col">Ditambahkan</th>
                                            <th scope="col">Harga</th>
                                            <th scope="col">Estimasi</th>
                                            <th scope="col">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody align="center">
                                        <?php $i = 1; ?>
                                        <?php foreach ($products as $product) : ?>
                                        <tr>
                                            <th scope="row"><?= $i; ?></th>
                                            <td class="align-middle">
                                                <img width="80px"
                                                    src="<?= base_url('assets/img/product_thumb/small/') . $product['thumb']; ?>"
                                                    alt="">
                                            </td>
                                            <td class="align-middle"><?= $product['title'] ?></td>
                                            <td class="align-middle">
                                                <?= (strlen($product['product_desc']) > 20) ? substr($product['product_desc'], 0, 20) . '...' : $product['product_desc'] ?>
                                            </td>
                                            <td class="align-middle"><?= $product['date_added'] ?></td>
                                            <td class="align-middle"><?= $product['name'] ?></td>
                                            <td class="align-middle"><?= $product['price'] ?></td>
                                            <td class="align-middle"><?= $product['estimate'] ?></td>
                                            <td class="align-middle">
                                                <div class="btn-group">
                                                    <button class="btn btn-primary btn-sm dropdown-toggle" type="button"
                                                        data-toggle="dropdown" aria-haspopup="true"
                                                        aria-expanded="false">
                                                        Aksi
                                                    </button>
                                                    <div class="tooltip-demo dropdown-menu">
                                                        <?php if ($product['thumb'] == 'no_thumb.jpg') : ?>
                                                        <a href="" class="dropdown-item" data-toggle="modal"
                                                            data-target="#newThumbModal<?= $product['id']; ?>"
                                                            data-popup="tooltip" data-placement="top"
                                                            title="Tambah thumb"><i class=" fas fa-fw fa-plus"></i>
                                                            thumb
                                                        </a>
                                                        <?php else : ?>
                                                        <a href="" class="dropdown-item" data-toggle="modal"
                                                            data-target="#newThumbModal<?= $product['id']; ?>"
                                                            data-popup="tooltip" data-placement="top"
                                                            title="Edit thumb"><i class=" fas fa-fw fa-edit"></i>
                                                            edit thumb
                                                        </a>
                                                        <a href="<?= base_url('produk/deletethumb/') . $product['id']; ?>"
                                                            class="dropdown-item del-btn" data-popup="tooltip"
                                                            data-placement="top" title="Hapus thumb"><i
                                                                class=" fas fa-fw fa-trash"></i>
                                                            hapus thumb
                                                        </a>
                                                        <?php endif; ?>
                                                        <div class="dropdown-divider"></div>
                                                        <a href="" class="dropdown-item " data-toggle="modal"
                                                            data-target="#editProdukModal<?= $product['id'] ?>"
                                                            data-popup="tooltip" data-placement="top"
                                                            title="Edit Data"><i class=" fas fa-fw fa-edit"></i>
                                                            edit</a>
                                                        <a href="<?= base_url('produk/deleteproduk/') . $product['id'] ?>"
                                                            class="dropdown-item fas del-btn" data-popup="tooltip"
                                                            data-placement="top" title="Delete Data"><i
                                                                class="fas fa-fw fa-trash-alt"></i>
                                                            hapus item</a>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <?php $i++ ?>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!--/. container-fluid -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->


<!-- Modal -->
<div class="modal fade" id="newProdukModal" tabindex="-1" role="dialog" aria-labelledby="newProdukModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title edittitle" id="newProdukModal">Tambah Produk</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?= base_url('produk'); ?>" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <input type="text" class="form-control" id="title" name="title" placeholder="Nama Produk">
                    </div>
                    <div class="form-group">
                        <textarea placeholder="Deskripsi Produk" type="textarea" class="form-control" id="product_desc"
                            name="product_desc"></textarea>
                    </div>

                    <div class="form-group">
                        <input type="number" class="form-control" id="price" name="price" placeholder="Harga">
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control" id="estimate" name="estimate" placeholder="Estimasi">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary editbutton"><i
                            class=" fas fa-fw fa-plus-square"></i>Add</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php foreach ($products as $product) : ?>

<div class="modal fade" id="editProdukModal<?= $product['id'] ?>" tabindex="-1" role="dialog"
    aria-labelledby="editProdukModal<?= $product['id'] ?>Label" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title edittitle" id="editProdukModal<?= $product['id'] ?>">Edit Buku</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?= form_open('produk/editproduk'); ?>
            <input type="hidden" name="id" value="<?= $product['id']; ?>">
            <div class="modal-body">
                <div class="form-group">
                    <input type="text" value="<?= $product['title']; ?>" class="form-control" id="title" name="title"
                        placeholder="Nama Produk">
                </div>
                <div class="form-group">
                    <textarea placeholder="Deskripsi Produk" type="textarea" class="form-control" id="product_desc"
                        name="product_desc"><?= $product['product_desc']; ?></textarea>
                </div>

                <div class="form-group">
                    <input type="number" value="<?= $product['price']; ?>" class="form-control" id="price" name="price"
                        placeholder="Harga">
                </div>
                <div class="form-group">
                    <input type="text" value="<?= $product['estimate']; ?>" class="form-control" id="estimate"
                        name="estimate" placeholder="Estimasi">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary editbutton"><i
                        class=" fas fa-fw fa-plus-square"></i>Add</button>
            </div>
            <?= form_close(); ?>
        </div>
    </div>
</div>

<?php endforeach; ?>

<!-- modal cover -->
<?php foreach ($products as $product) : ?>

<div class="modal fade" id="newThumbModal<?= $product['id']; ?>" tabindex="-1" role="dialog"
    aria-labelledby="newThumbModal<?= $product['id']; ?>Label" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title edittitle" id="newThumbModal<?= $product['id']; ?>">Tambah Menu</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <?= form_open_multipart('produk/thumb'); ?>
            <input type="hidden" name="id" value="<?= $product['id']; ?>">
            <div class="modal-body">
                <div class="form-group">
                    <div class="custom-file">
                        <input type="file" class="custom-file-input" id="thumb" name="thumb" accept="image/*">
                        <label class="custom-file-label" for="thumb">Thumb Produk</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary editbutton"><i
                            class=" fas fa-fw fa-plus-square"></i>Add</button>
                </div>
                <?= form_close(); ?>
            </div>
        </div>
    </div>
</div>

<?php endforeach; ?>