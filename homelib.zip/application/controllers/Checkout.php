<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Checkout extends CI_Controller 
{
    // public function __construct()
    // {
    //     parent::__construct();
    //     if (!$this->session->userdata('email')) {
    //         # code...
    //         redirect('landing');
    //     }
    // }
    public function index()
    {
        $data['title']  = 'Checkout';
        $data['user']   = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('products', 'Produk', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata(
                'error',
                'Tidak ada produk yang dipilih'
            );
            redirect('katalog');

        } else {
            $product    = $this->input->POST('products');
            $decode     = json_decode($product, TRUE);

            $products   = [];

            $i = 0;
            foreach ($decode as $produc) {
                $products[$i] = $this->database->getProductById($produc['product_id']);
                $products[$i]['qty'] = $produc['qty'];
                $i++;
            }

            $data['products']   = $products;
            $data['json']       = $product;
            $data['payments']   = $this->database->getAll('product_payment_method');

            $this->load->view('frontend/template/header', $data);
            $this->load->view('frontend/template/navbar', $data);
            $this->load->view('frontend/checkout/index', $data);
            $this->load->view('frontend/template/footer');
        }

    }
}