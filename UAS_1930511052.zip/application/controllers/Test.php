<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Test extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
    }

    public function login()
    {
        $this->session->set_userdata(
            [
                'email' => 'admin@homelib.com',
                'role_id'   => 1
            ]
        );
    }

    public function cart()
    {
        $data   = [
            'id'      => 10,
            'user_id' => 2,  
            'qty'     => 1,
            'price'   => 39.95,
            'name'    => 'Buku IT',
            'options' => array('Size' => 'L', 'Color' => 'Red')
        ];

        $this->cart->insert($data);
    }

    public function removeCart()
    {
        $this->cart->destroy();
    }

}